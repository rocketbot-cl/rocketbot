from comtypes.gen import _EAB22AC0_30C1_11CF_A7EB_0000C05BAE0B_0_1_1
globals().update(_EAB22AC0_30C1_11CF_A7EB_0000C05BAE0B_0_1_1.__dict__)
__name__ = 'comtypes.gen.SHDocVw'
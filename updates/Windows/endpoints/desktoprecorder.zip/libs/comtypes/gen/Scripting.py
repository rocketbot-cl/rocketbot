from comtypes.gen import _420B2830_E718_11CF_893D_00A0C9054228_0_1_0
globals().update(_420B2830_E718_11CF_893D_00A0C9054228_0_1_0.__dict__)
__name__ = 'comtypes.gen.Scripting'
from comtypes.gen import _1EA4DBF0_3C3B_11CF_810C_00AA00389B71_0_1_1
globals().update(_1EA4DBF0_3C3B_11CF_810C_00AA00389B71_0_1_1.__dict__)
__name__ = 'comtypes.gen.Accessibility'
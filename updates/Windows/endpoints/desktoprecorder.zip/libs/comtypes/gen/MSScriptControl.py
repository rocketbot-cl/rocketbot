from comtypes.gen import _0E59F1D2_1FBE_11D0_8FF2_00A0D10038BC_0_1_0
globals().update(_0E59F1D2_1FBE_11D0_8FF2_00A0D10038BC_0_1_0.__dict__)
__name__ = 'comtypes.gen.MSScriptControl'
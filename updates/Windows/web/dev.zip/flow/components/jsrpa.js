Vue.component('js-execjs', {
    template:`
    <div class="row">
    basura
    </div>
    `,
    props:['commandData', 'commandFather']
})
